function Actor({ name }) {
  return <li>Name: {name}</li>;
}

export default Actor;
